# Pathfinding Lab — versión web

## Probar localmente

1. Instala Python 3.11 o 3.12.
2. Abre una terminal dentro de esta carpeta.
3. Instala Pygbag:

   python -m pip install --upgrade pygbag

4. Ejecuta el servidor web:

   python -m pygbag .

5. Abre en el navegador la dirección que aparezca en la terminal.
   Normalmente será:

   http://localhost:8000

No abras `index.html` directamente con doble clic: el proyecto necesita ejecutarse mediante un servidor HTTP.

## Crear la compilación web

Ejecuta:

    python -m pygbag --build .

La compilación se genera dentro de:

    build/web/

Esa carpeta contiene `index.html` y los demás archivos web.

## Publicar en itch.io

1. Entra a `build/web/`.
2. Selecciona todo el contenido de esa carpeta.
3. Comprímelo como ZIP.
4. Verifica que `index.html` esté en la raíz del ZIP.
5. En itch.io crea un proyecto de tipo HTML.
6. Sube el ZIP y marca la opción para ejecutarlo en el navegador.

## Publicar en GitHub Pages

Sube el contenido de `build/web/` a una rama o carpeta configurada como origen de GitHub Pages.
No subas únicamente `main.py`: GitHub Pages debe recibir la compilación web.
