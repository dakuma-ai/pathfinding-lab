import pygame
import asyncio
import random
import heapq
import time
import sys
import json
import math

from enum import Enum
from collections import deque


# ============================================================
# CONFIGURACIÓN VISUAL
# ============================================================

DARK = {
    "bg": (15, 18, 25),
    "grid_bg": (30, 36, 49),
    "grid_line": (46, 54, 72),
    "panel": (25, 30, 42),
    "panel_2": (34, 40, 55),
    "border": (57, 67, 88),
    "text": (236, 240, 247),
    "muted": (150, 160, 181),
    "accent": (124, 93, 246),
    "accent_hover": (143, 116, 255),
    "button": (43, 50, 68),
    "button_hover": (57, 66, 89),
    "obstacle": (10, 13, 20),
    "visited_start": (39, 76, 112),
    "visited_end": (83, 154, 211),
    "frontier": (240, 162, 67),
    "current": (224, 92, 255),
    "path": (255, 205, 75),
    "start": (55, 205, 139),
    "goal": (241, 83, 80),
    "npc": (90, 160, 255),
    "success": (86, 213, 151),
    "danger": (226, 82, 90),
}

LIGHT = {
    "bg": (232, 236, 244),
    "grid_bg": (246, 248, 252),
    "grid_line": (210, 217, 229),
    "panel": (251, 252, 255),
    "panel_2": (238, 242, 249),
    "border": (193, 201, 216),
    "text": (27, 33, 45),
    "muted": (95, 106, 126),
    "accent": (102, 76, 214),
    "accent_hover": (120, 92, 229),
    "button": (225, 230, 240),
    "button_hover": (213, 220, 233),
    "obstacle": (52, 58, 70),
    "visited_start": (178, 214, 241),
    "visited_end": (71, 145, 202),
    "frontier": (239, 158, 45),
    "current": (168, 54, 205),
    "path": (245, 185, 35),
    "start": (42, 172, 112),
    "goal": (218, 68, 69),
    "npc": (55, 126, 220),
    "success": (39, 160, 104),
    "danger": (207, 65, 75),
}


# ============================================================
# ENUMS Y DATOS
# ============================================================

class TileType(Enum):
    EMPTY = 0
    OBSTACLE = 1
    START = 2
    GOAL = 3


class Algorithm(Enum):
    BFS = "BFS"
    DFS = "DFS"
    ASTAR = "A*"
    DIJKSTRA = "Dijkstra"
    GREEDY = "Greedy"


class Tool(Enum):
    SELECT = "Seleccionar"
    START = "Colocar inicio"
    GOAL = "Colocar meta"
    OBSTACLE = "Dibujar obstáculos"
    ERASE = "Borrar"
    NPC = "Crear NPC"


ALGORITHM_INFO = {
    Algorithm.BFS: {
        "description": "Explora por niveles usando una cola FIFO.",
        "time": "O(V + E)",
        "memory": "O(V)",
        "optimal": "Sí, con costos uniformes",
    },
    Algorithm.DFS: {
        "description": "Avanza en profundidad usando una pila.",
        "time": "O(V + E)",
        "memory": "O(V)",
        "optimal": "No",
    },
    Algorithm.ASTAR: {
        "description": "Combina costo recorrido y heurística.",
        "time": "O(b^d) en el peor caso",
        "memory": "O(b^d)",
        "optimal": "Sí, con heurística admisible",
    },
    Algorithm.DIJKSTRA: {
        "description": "Expande siempre el nodo de menor costo acumulado.",
        "time": "O((V + E) log V)",
        "memory": "O(V)",
        "optimal": "Sí, con costos no negativos",
    },
    Algorithm.GREEDY: {
        "description": "Prioriza el nodo aparentemente más cercano a la meta.",
        "time": "O(b^m) en el peor caso",
        "memory": "O(b^m)",
        "optimal": "No",
    },
}


class NPC:
    def __init__(self, x, y, algorithm):
        self.x = x
        self.y = y
        self.algorithm = algorithm
        self.path = []
        self.full_path = []
        self.color = tuple(random.randint(90, 245) for _ in range(3))

    def set_path(self, path):
        self.full_path = path.copy()
        self.path = path[1:] if len(path) > 1 else []

    def move_one_step(self):
        """Mueve al NPC una sola celda en dirección cardinal.

        Se rechaza cualquier salto diagonal o de más de una celda, incluso si
        una ruta inválida llegara a almacenarse accidentalmente.
        """
        if not self.path:
            return False

        next_x, next_y = self.path[0]
        distance = abs(next_x - self.x) + abs(next_y - self.y)
        if distance != 1:
            self.path = []
            return False

        self.path.pop(0)
        self.x, self.y = next_x, next_y
        return True


# ============================================================
# BÚSQUEDA INCREMENTAL
# ============================================================

class SearchSession:
    """Ejecuta un algoritmo nodo por nodo y conserva frontera y orden de visita."""

    def __init__(self, system, start, goal, algorithm):
        self.system = system
        self.start = start
        self.goal = goal
        self.algorithm = algorithm
        self.finished = False
        self.found = False
        self.path = []
        self.current = None
        self.came_from = {start: None}
        self.visited = set()
        self.visit_order = []
        self.discovered = {start}
        self.counter = 0
        self.g_score = {start: 0}

        if algorithm == Algorithm.BFS:
            self.frontier = deque([start])
        elif algorithm == Algorithm.DFS:
            self.frontier = [start]
        else:
            self.frontier = []
            priority = self._priority(start, 0)
            heapq.heappush(self.frontier, (priority, self.counter, start))

    def _priority(self, node, g):
        h = self.system.heuristic(node, self.goal)
        if self.algorithm == Algorithm.ASTAR:
            return g + h
        if self.algorithm == Algorithm.DIJKSTRA:
            return g
        return h

    def frontier_nodes(self):
        if self.algorithm == Algorithm.BFS:
            return list(self.frontier)
        if self.algorithm == Algorithm.DFS:
            return list(self.frontier)
        return [item[2] for item in self.frontier]

    def _pop(self):
        # Una frontera vacía significa que no quedan nodos por explorar.
        # Nunca se debe llamar popleft() o pop() sin comprobarla primero.
        if not self.frontier:
            return None

        if self.algorithm == Algorithm.BFS:
            return self.frontier.popleft()
        if self.algorithm == Algorithm.DFS:
            return self.frontier.pop()

        while self.frontier:
            _, _, node = heapq.heappop(self.frontier)
            if node not in self.visited:
                return node
        return None

    def _push(self, node, g):
        if self.algorithm == Algorithm.BFS:
            self.frontier.append(node)
        elif self.algorithm == Algorithm.DFS:
            self.frontier.append(node)
        else:
            self.counter += 1
            heapq.heappush(self.frontier, (self._priority(node, g), self.counter, node))

    def step(self):
        if self.finished:
            return

        # Si la frontera está vacía, la búsqueda terminó sin encontrar ruta.
        if not self.frontier:
            self.finished = True
            self.found = False
            self.current = None
            return

        current = self._pop()
        if current is None:
            self.finished = True
            self.found = False
            self.current = None
            return

        if current in self.visited:
            return

        self.current = current
        self.visited.add(current)
        self.visit_order.append(current)

        if current == self.goal:
            self.finished = True
            self.found = True
            self.path = self.system.reconstruct_path(self.came_from, self.start, self.goal)
            return

        for neighbor in self.system.get_neighbors(*current):
            if neighbor in self.visited:
                continue

            tentative_g = self.g_score[current] + 1

            if self.algorithm in (Algorithm.BFS, Algorithm.DFS, Algorithm.GREEDY):
                if neighbor in self.discovered:
                    continue
                self.discovered.add(neighbor)
                self.came_from[neighbor] = current
                self.g_score[neighbor] = tentative_g
                self._push(neighbor, tentative_g)
            else:
                if tentative_g < self.g_score.get(neighbor, float("inf")):
                    self.g_score[neighbor] = tentative_g
                    self.came_from[neighbor] = current
                    self.discovered.add(neighbor)
                    self._push(neighbor, tentative_g)

    def run_to_end(self):
        while not self.finished:
            self.step()
        return self.path, self.visited


# ============================================================
# SISTEMA PRINCIPAL DE PATHFINDING
# ============================================================

class PathfindingSystem:
    def __init__(self, width=60, height=45):
        self.width = width
        self.height = height
        self.grid = [[TileType.EMPTY for _ in range(width)] for _ in range(height)]
        self.start = (3, 3)
        self.goal = (56, 40)
        self.npcs = []
        self.selected_npc = None
        self.current_path = []
        self.visited_nodes = set()
        self.visit_order = []
        self.frontier_nodes = set()
        self.current_node = None
        self.path_cache = {}
        self.algorithm_stats = {algorithm: self.empty_stats() for algorithm in Algorithm}

    @staticmethod
    def empty_stats():
        return {
            "mean": 0.0,
            "min": 0.0,
            "max": 0.0,
            "std": 0.0,
            "length": 0,
            "steps": 0,
            "visited_mean": 0.0,
            "visited": 0,
            "found": False,
            "optimal": False,
        }

    @staticmethod
    def calculate_mean(values):
        if not values:
            return 0.0
        return sum(values) / len(values)

    @staticmethod
    def calculate_std(values):
        if len(values) <= 1:
            return 0.0

        mean = sum(values) / len(values)
        variance = sum((value - mean) ** 2 for value in values) / len(values)
        return math.sqrt(variance)

    def clear(self):
        self.grid = [[TileType.EMPTY for _ in range(self.width)] for _ in range(self.height)]
        self.path_cache.clear()

    def set_cell(self, x, y, tile):
        if 0 <= x < self.width and 0 <= y < self.height:
            self.grid[y][x] = tile
            self.path_cache.clear()

    def is_walkable(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height and self.grid[y][x] != TileType.OBSTACLE

    def get_neighbors(self, x, y):
        result = []
        for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0)):
            nx, ny = x + dx, y + dy
            if self.is_walkable(nx, ny):
                result.append((nx, ny))
        return result

    @staticmethod
    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    @staticmethod
    def reconstruct_path(came_from, start, goal):
        if goal != start and goal not in came_from:
            return []
        node = goal
        path = []
        while node is not None:
            path.append(node)
            if node == start:
                break
            node = came_from.get(node)
            if node is None:
                return []
        return list(reversed(path))

    def create_session(self, algorithm, start=None, goal=None):
        return SearchSession(self, start or self.start, goal or self.goal, algorithm)

    def find_path(self, start, goal, algorithm, use_cache=True):
        key = (start, goal, algorithm, self.grid_signature())
        if use_cache and key in self.path_cache:
            return self.path_cache[key]
        session = self.create_session(algorithm, start, goal)
        result = session.run_to_end()
        if use_cache:
            self.path_cache[key] = result
        return result

    def grid_signature(self):
        return hash(tuple(tuple(cell.value for cell in row) for row in self.grid))

    def benchmark_algorithms(self, repetitions=30):
        results = {}
        for algorithm in Algorithm:
            times = []
            visited_counts = []
            path = []
            for _ in range(repetitions):
                begin = time.perf_counter_ns()
                session = self.create_session(algorithm)
                path, visited = session.run_to_end()
                elapsed_ms = (time.perf_counter_ns() - begin) / 1_000_000
                times.append(elapsed_ms)
                visited_counts.append(len(visited))

            results[algorithm] = {
                "mean": self.calculate_mean(times),
                "min": min(times),
                "max": max(times),
                "std": self.calculate_std(times),
                "length": len(path),
                "steps": max(0, len(path) - 1),
                "visited_mean": self.calculate_mean(visited_counts),
                "visited": round(self.calculate_mean(visited_counts)),
                "found": bool(path),
                "optimal": False,
            }

        valid = [d for d in results.values() if d["found"]]
        shortest = min((d["steps"] for d in valid), default=None)
        for algorithm, data in results.items():
            data["optimal"] = data["found"] and data["steps"] == shortest
            self.algorithm_stats[algorithm] = data
        return results


# ============================================================
# COMPONENTES DE INTERFAZ
# ============================================================

class Button:
    def __init__(self, rect, text, action=None, icon=""):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.action = action
        self.icon = icon
        self.active = False
        self.disabled = False

    def draw(self, screen, font, theme):
        hovered = self.rect.collidepoint(pygame.mouse.get_pos()) and not self.disabled
        color = theme["accent"] if self.active else theme["button"]
        if hovered:
            color = theme["accent_hover"] if self.active else theme["button_hover"]
        if self.disabled:
            color = theme["panel_2"]
        pygame.draw.rect(screen, color, self.rect, border_radius=7)
        pygame.draw.rect(screen, theme["border"], self.rect, 1, border_radius=7)
        label = f"{self.icon} {self.text}".strip()
        surface = font.render(label, True, theme["muted"] if self.disabled else theme["text"])
        screen.blit(surface, surface.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return not self.disabled and self.rect.collidepoint(pos)


class Slider:
    def __init__(self, rect, minimum, maximum, value, label, suffix=""):
        self.rect = pygame.Rect(rect)
        self.minimum = minimum
        self.maximum = maximum
        self.value = value
        self.label = label
        self.suffix = suffix
        self.dragging = False

    def _set_from_x(self, x):
        ratio = max(0.0, min(1.0, (x - self.rect.x) / max(1, self.rect.width)))
        self.value = self.minimum + ratio * (self.maximum - self.minimum)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            hit = self.rect.inflate(0, 14)
            if hit.collidepoint(event.pos):
                self.dragging = True
                self._set_from_x(event.pos[0])
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self._set_from_x(event.pos[0])
            return True
        return False

    def draw(self, screen, font, theme, decimals=0):
        value_text = f"{self.value:.{decimals}f}{self.suffix}"
        label = font.render(f"{self.label}: {value_text}", True, theme["text"])
        screen.blit(label, (self.rect.x, self.rect.y - 20))
        pygame.draw.rect(screen, theme["panel_2"], self.rect, border_radius=5)
        ratio = (self.value - self.minimum) / (self.maximum - self.minimum)
        filled = pygame.Rect(self.rect.x, self.rect.y, int(self.rect.width * ratio), self.rect.height)
        pygame.draw.rect(screen, theme["accent"], filled, border_radius=5)
        knob_x = self.rect.x + int(self.rect.width * ratio)
        pygame.draw.circle(screen, theme["text"], (knob_x, self.rect.centery), 7)


# ============================================================
# GENERADORES DE MAPAS
# ============================================================

class MapGenerator:
    @staticmethod
    def empty_grid(system):
        system.clear()

    @staticmethod
    def preserve_special(system):
        system.grid[system.start[1]][system.start[0]] = TileType.START
        system.grid[system.goal[1]][system.goal[0]] = TileType.GOAL
        for npc in system.npcs:
            if system.grid[npc.y][npc.x] == TileType.OBSTACLE:
                system.grid[npc.y][npc.x] = TileType.EMPTY

    @staticmethod
    def guarantee_path(system):
        path, _ = system.find_path(system.start, system.goal, Algorithm.BFS, use_cache=False)
        if path:
            return
        x, y = system.start
        gx, gy = system.goal
        while x != gx:
            x += 1 if gx > x else -1
            if (x, y) not in (system.start, system.goal):
                system.grid[y][x] = TileType.EMPTY
        while y != gy:
            y += 1 if gy > y else -1
            if (x, y) not in (system.start, system.goal):
                system.grid[y][x] = TileType.EMPTY

    @staticmethod
    def random_obstacles(system, density):
        protected = {system.start, system.goal, *((npc.x, npc.y) for npc in system.npcs)}
        for _ in range(60):
            system.clear()
            for y in range(system.height):
                for x in range(system.width):
                    if (x, y) not in protected and random.random() < density:
                        system.grid[y][x] = TileType.OBSTACLE
            MapGenerator.preserve_special(system)
            if system.find_path(system.start, system.goal, Algorithm.BFS, use_cache=False)[0]:
                return
        MapGenerator.guarantee_path(system)
        MapGenerator.preserve_special(system)


# ============================================================
# APLICACIÓN
# ============================================================

class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Pathfinding Lab — Simulador educativo")

        self.system = PathfindingSystem()
        self.theme_name = "dark"
        self.theme = DARK
        self.sidebar_width = 420
        self.bottom_height = 210
        self.cell_size = 14
        self.grid_width_px = self.system.width * self.cell_size
        self.grid_height_px = self.system.height * self.cell_size
        self.screen = pygame.display.set_mode(
            (
                self.grid_width_px + self.sidebar_width,
                self.grid_height_px + self.bottom_height,
            )
        )
        self.clock = pygame.time.Clock()
        self.running = True

        self.font = pygame.font.SysFont("Segoe UI", 13)
        self.font_bold = pygame.font.SysFont("Segoe UI", 13, bold=True)
        self.small_font = pygame.font.SysFont("Segoe UI", 11)
        self.tiny_font = pygame.font.SysFont("Segoe UI", 10)
        self.title_font = pygame.font.SysFont("Segoe UI", 22, bold=True)

        self.current_algorithm = Algorithm.ASTAR
        self.active_tool = Tool.SELECT
        self.session = None
        self.simultaneous_sessions = {}
        self.simultaneous_mode = False
        self.animation_enabled = False
        self.paused = True
        self.last_step_time = 0
        self.speed_slider = Slider((0, 0, 100, 8), 1, 120, 30, "Velocidad", " pasos/s")
        self.density_slider = Slider((0, 0, 100, 8), 5, 60, 30, "Densidad", "%")
        self.benchmark_repetitions = 10
        self.chart_metric = "Tiempo promedio"
        self.message = ""
        self.message_time = 0
        self.drawing = False
        self.hover_cell = None
        self.best_algorithm = None

        # Ejecuta las estadísticas después de que la interfaz haya cargado.
        # Esto evita bloquear la inicialización en el navegador.
        self.pending_initial_benchmark = True
        self.initial_benchmark_time = pygame.time.get_ticks()

        self.auto_move_npcs = False
        self.npc_timer = 0
        self.map_type = "Obstáculos aleatorios"
        # Generadores simples y estables, similares al programa original.
        self.map_types = [
            "Obstáculos aleatorios",
            "Mapa abierto",
        ]
        self.map_dropdown_open = False
        self.metric_dropdown_open = False
        self.buttons = {}

        self.load_default_map()
        self.show_algorithm_result()

        # En la versión web no se ejecuta el benchmark durante la carga.
        # Se puede iniciar manualmente con el botón "Comparar".

    def show_message(self, text):
        self.message = text
        self.message_time = pygame.time.get_ticks()

    def load_default_map(self):
        self.system.clear()
        self.system.start = (3, 3)
        self.system.goal = (56, 40)
        for x in range(6, 24):
            self.system.grid[8][x] = TileType.OBSTACLE
        for x in range(28, 46):
            self.system.grid[15][x] = TileType.OBSTACLE
        for y in range(10, 34):
            self.system.grid[y][15] = TileType.OBSTACLE
        for y in range(6, 22):
            self.system.grid[y][45] = TileType.OBSTACLE
        MapGenerator.preserve_special(self.system)

    def reset_search(self):
        """Prepara una animación desde cero sin ejecutarla automáticamente."""
        self.session = self.system.create_session(self.current_algorithm)
        self.system.current_path = []
        self.system.visited_nodes = set()
        self.system.visit_order = []
        self.system.frontier_nodes = set(self.session.frontier_nodes())
        self.system.current_node = None
        self.paused = True
        self.last_step_time = pygame.time.get_ticks()
        self.reset_simultaneous_sessions()

    def show_algorithm_result(self):
        """Calcula y muestra inmediatamente el resultado completo del algoritmo activo."""
        self.session = self.system.create_session(self.current_algorithm)
        self.session.run_to_end()
        self.system.current_path = self.session.path.copy()
        self.system.visited_nodes = self.session.visited.copy()
        self.system.visit_order = self.session.visit_order.copy()
        self.system.frontier_nodes = set()
        self.system.current_node = self.session.current
        self.paused = True
        self.reset_simultaneous_sessions()

    def toggle_animation(self):
        self.animation_enabled = not self.animation_enabled
        self.simultaneous_mode = False
        if self.animation_enabled:
            self.reset_search()
            self.show_message("Animación activada: usa Siguiente paso o Reproducir")
        else:
            self.show_algorithm_result()
            self.show_message("Animación desactivada: mostrando resultado completo")

    def reset_simultaneous_sessions(self):
        self.simultaneous_sessions = {
            algorithm: self.system.create_session(algorithm)
            for algorithm in Algorithm
        }

    def step_search(self):
        if not self.animation_enabled and not self.simultaneous_mode:
            self.show_message("Activa Mostrar animación para avanzar paso a paso")
            return
        if self.simultaneous_mode:
            all_finished = True
            for session in self.simultaneous_sessions.values():
                if not session.finished:
                    session.step()
                    all_finished = False
            if all_finished:
                self.paused = True
                self.show_message("Comparación simultánea terminada")
            return

        if self.session is None or self.session.finished:
            return
        self.session.step()
        self.system.visited_nodes = self.session.visited.copy()
        self.system.visit_order = self.session.visit_order.copy()
        self.system.frontier_nodes = set(self.session.frontier_nodes())
        self.system.current_node = self.session.current
        self.system.current_path = self.session.path.copy()
        if self.session.finished:
            self.paused = True
            self.show_message("Ruta encontrada" if self.session.found else "No existe una ruta")

    def update_search_animation(self):
        if not self.animation_enabled and not self.simultaneous_mode:
            return
        if self.paused:
            return
        now = pygame.time.get_ticks()
        interval = 1000 / max(1, self.speed_slider.value)
        steps = 0
        while now - self.last_step_time >= interval and steps < 8:
            self.step_search()
            self.last_step_time += interval
            steps += 1

    def run_benchmark(self):
        self.show_message(f"Comparando {self.benchmark_repetitions} ejecuciones por algoritmo")
        results = self.system.benchmark_algorithms(self.benchmark_repetitions)
        candidates = [(a, d) for a, d in results.items() if d["found"]]
        self.best_algorithm = min(
            candidates,
            key=lambda item: (
                0 if item[1]["optimal"] else 1,
                item[1]["visited_mean"],
                item[1]["mean"],
            ),
            default=(None, None),
        )[0]

    def refresh_after_map_change(self, benchmark=True):
        self.system.path_cache.clear()
        if self.animation_enabled:
            self.reset_search()
        else:
            self.show_algorithm_result()
        self.update_all_npc_paths()
        if benchmark:
            self.run_benchmark()

    def generate_selected_map(self):
        """Genera mapas sencillos sin ejecutar procesos pesados automáticamente."""
        try:
            if self.map_type == "Mapa abierto":
                MapGenerator.empty_grid(self.system)
                MapGenerator.preserve_special(self.system)
            else:
                density = max(0.05, min(0.60, self.density_slider.value / 100))
                MapGenerator.random_obstacles(self.system, density)

            # Mostrar inmediatamente el resultado del algoritmo seleccionado.
            # La comparativa completa queda disponible mediante su botón.
            self.refresh_after_map_change(benchmark=False)
            self.show_message(f"Mapa generado: {self.map_type}")
        except Exception as error:
            # Evita que un error del generador cierre toda la aplicación.
            self.load_default_map()
            self.refresh_after_map_change(benchmark=False)
            self.show_message(f"No se pudo generar el mapa; se restauró el mapa inicial")
            print(f"Error al generar mapa: {error}")

    def set_start(self, pos):
        if pos == self.system.goal:
            self.show_message("El inicio no puede coincidir con la meta")
            return
        if self.system.start:
            ox, oy = self.system.start
            if self.system.grid[oy][ox] == TileType.START:
                self.system.grid[oy][ox] = TileType.EMPTY
        self.system.start = pos
        self.system.grid[pos[1]][pos[0]] = TileType.START
        self.refresh_after_map_change()

    def set_goal(self, pos):
        if pos == self.system.start:
            self.show_message("La meta no puede coincidir con el inicio")
            return
        if self.system.goal:
            ox, oy = self.system.goal
            if self.system.grid[oy][ox] == TileType.GOAL:
                self.system.grid[oy][ox] = TileType.EMPTY
        self.system.goal = pos
        self.system.grid[pos[1]][pos[0]] = TileType.GOAL
        self.refresh_after_map_change()

    def add_npc(self, pos):
        if self.system.grid[pos[1]][pos[0]] == TileType.OBSTACLE or pos in (self.system.start, self.system.goal):
            self.show_message("El NPC necesita una celda libre")
            return
        npc = NPC(*pos, self.current_algorithm)
        self.system.npcs.append(npc)
        self.update_npc_path(npc)
        self.show_message(f"NPC creado en {pos}")

    def update_npc_path(self, npc):
        """Recalcula la ruta del NPC usando el algoritmo activo en la demostración."""
        npc.algorithm = self.current_algorithm
        path, _ = self.system.find_path(
            (npc.x, npc.y),
            self.system.goal,
            self.current_algorithm,
            use_cache=False,
        )
        npc.set_path(path)

    def update_all_npc_paths(self):
        for npc in self.system.npcs:
            self.update_npc_path(npc)

    def move_npcs(self):
        moved = 0
        for npc in self.system.npcs:
            if npc.move_one_step():
                moved += 1
                self.update_npc_path(npc)
        if moved:
            self.show_message(f"{moved} NPC movidos con {self.current_algorithm.value}")
        elif self.system.npcs:
            self.show_message("Los NPC no tienen una ruta disponible")
        else:
            self.show_message("No hay NPC creados")

    def grid_geometry(self):
        available_w = self.screen.get_width() - self.sidebar_width
        available_h = self.screen.get_height() - self.bottom_height
        self.cell_size = max(7, min(18, available_w // self.system.width, available_h // self.system.height))
        self.grid_width_px = self.system.width * self.cell_size
        self.grid_height_px = self.system.height * self.cell_size
        return pygame.Rect(0, 0, self.grid_width_px, self.grid_height_px)

    def cell_at_mouse(self, pos):
        grid_rect = self.grid_geometry()
        if not grid_rect.collidepoint(pos):
            return None
        x = pos[0] // self.cell_size
        y = pos[1] // self.cell_size
        if 0 <= x < self.system.width and 0 <= y < self.system.height:
            return (x, y)
        return None

    def blend(self, a, b, t):
        return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    def draw_path_polyline(self, path, area_origin=(0, 0), cell_size=None):
        if len(path) < 2:
            return
        cs = cell_size or self.cell_size
        ox, oy = area_origin
        points = [(ox + x * cs + cs // 2, oy + y * cs + cs // 2) for x, y in path]
        pygame.draw.lines(self.screen, self.theme["path"], False, points, max(2, cs // 4))
        for i in range(1, len(points), max(1, len(points) // 10)):
            a, b = points[i - 1], points[i]
            angle = math.atan2(b[1] - a[1], b[0] - a[0])
            size = max(3, cs // 3)
            left = (b[0] - size * math.cos(angle - 0.6), b[1] - size * math.sin(angle - 0.6))
            right = (b[0] - size * math.cos(angle + 0.6), b[1] - size * math.sin(angle + 0.6))
            pygame.draw.polygon(self.screen, self.theme["path"], [b, left, right])

    def draw_single_grid(self):
        ps = self.system
        grid_rect = self.grid_geometry()
        pygame.draw.rect(self.screen, self.theme["grid_bg"], grid_rect)
        visit_index = {node: i for i, node in enumerate(ps.visit_order)}
        total = max(1, len(ps.visit_order) - 1)

        for y in range(ps.height):
            for x in range(ps.width):
                rect = pygame.Rect(x * self.cell_size, y * self.cell_size, self.cell_size, self.cell_size)
                tile = ps.grid[y][x]
                color = self.theme["grid_bg"]
                if tile == TileType.OBSTACLE:
                    color = self.theme["obstacle"]
                elif (x, y) in ps.frontier_nodes:
                    color = self.theme["frontier"]
                elif (x, y) in visit_index:
                    t = visit_index[(x, y)] / total
                    color = self.blend(self.theme["visited_start"], self.theme["visited_end"], t)
                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, self.theme["grid_line"], rect, 1)

        if ps.current_node is not None and self.animation_enabled:
            cx, cy = ps.current_node
            current_rect = pygame.Rect(
                cx * self.cell_size + 1, cy * self.cell_size + 1,
                max(2, self.cell_size - 2), max(2, self.cell_size - 2)
            )
            pygame.draw.rect(self.screen, self.theme["current"], current_rect, max(2, self.cell_size // 5))

        self.draw_path_polyline(ps.current_path)
        self.draw_markers(0, 0, self.cell_size)

        if self.hover_cell:
            hx, hy = self.hover_cell
            hover_rect = pygame.Rect(hx * self.cell_size, hy * self.cell_size, self.cell_size, self.cell_size)
            pygame.draw.rect(self.screen, self.theme["text"], hover_rect, 2)

    def draw_markers(self, ox, oy, cs, include_npcs=True):
        pulse = 1 + 0.12 * math.sin(pygame.time.get_ticks() / 180)
        for pos, color, label in (
            (self.system.start, self.theme["start"], "I"),
            (self.system.goal, self.theme["goal"], "M"),
        ):
            if pos is None:
                continue
            cx = ox + pos[0] * cs + cs // 2
            cy = oy + pos[1] * cs + cs // 2
            radius = max(3, int((cs // 2 - 1) * pulse))
            pygame.draw.circle(self.screen, color, (cx, cy), radius)
            if cs >= 12:
                text = self.tiny_font.render(label, True, self.theme["text"])
                self.screen.blit(text, text.get_rect(center=(cx, cy)))
        if include_npcs:
            for npc in self.system.npcs:
                cx = ox + npc.x * cs + cs // 2
                cy = oy + npc.y * cs + cs // 2
                pygame.draw.circle(self.screen, npc.color, (cx, cy), max(3, cs // 2 - 2))
                pygame.draw.circle(self.screen, self.theme["bg"], (cx, cy), max(3, cs // 2 - 2), 1)

    def draw_simultaneous(self):
        area_w = self.screen.get_width() - self.sidebar_width
        area_h = self.screen.get_height() - self.bottom_height
        cols, rows = 3, 2
        margin = 8
        panel_w = (area_w - margin * (cols + 1)) // cols
        panel_h = (area_h - margin * (rows + 1)) // rows
        algorithms = list(Algorithm)
        for index, algorithm in enumerate(algorithms):
            col = index % cols
            row = index // cols
            rect = pygame.Rect(
                margin + col * (panel_w + margin),
                margin + row * (panel_h + margin),
                panel_w,
                panel_h,
            )
            pygame.draw.rect(self.screen, self.theme["panel"], rect, border_radius=8)
            pygame.draw.rect(self.screen, self.theme["border"], rect, 1, border_radius=8)
            title = self.font_bold.render(algorithm.value, True, self.theme["text"])
            self.screen.blit(title, (rect.x + 8, rect.y + 6))
            top = rect.y + 27
            cs = max(2, min((rect.width - 12) // self.system.width, (rect.height - 35) // self.system.height))
            ox = rect.x + (rect.width - self.system.width * cs) // 2
            oy = top + max(0, (rect.bottom - top - self.system.height * cs) // 2)
            session = self.simultaneous_sessions[algorithm]
            visited = session.visited
            frontier = set(session.frontier_nodes())
            for y in range(self.system.height):
                for x in range(self.system.width):
                    cell = pygame.Rect(ox + x * cs, oy + y * cs, cs, cs)
                    if self.system.grid[y][x] == TileType.OBSTACLE:
                        color = self.theme["obstacle"]
                    elif (x, y) in frontier:
                        color = self.theme["frontier"]
                    elif (x, y) in visited:
                        color = self.theme["visited_end"]
                    else:
                        color = self.theme["grid_bg"]
                    pygame.draw.rect(self.screen, color, cell)
            self.draw_path_polyline(session.path, (ox, oy), cs)
            self.draw_markers(ox, oy, cs, include_npcs=False)

    def draw_panel(self, rect, title=None):
        """Dibuja un panel reutilizable para la barra lateral y zona inferior."""
        pygame.draw.rect(self.screen, self.theme["panel"], rect, border_radius=9)
        pygame.draw.rect(self.screen, self.theme["border"], rect, 1, border_radius=9)

        if title:
            title_surface = self.tiny_font.render(title.upper(), True, self.theme["muted"])
            self.screen.blit(title_surface, (rect.x + 10, rect.y + 8))

    def draw_sidebar(self):
        x = self.screen.get_width() - self.sidebar_width
        h = self.screen.get_height()
        pygame.draw.rect(self.screen, self.theme["bg"], (x, 0, self.sidebar_width, h))
        pygame.draw.line(self.screen, self.theme["border"], (x, 0), (x, h), 1)
        pad = 14
        content_x = x + pad
        width = self.sidebar_width - pad * 2

        self.screen.blit(self.title_font.render("PATHFINDING LAB", True, self.theme["text"]), (content_x, 12))
        self.screen.blit(self.small_font.render("Simulación educativa y comparación estadística", True, self.theme["muted"]), (content_x, 42))

        # Algoritmos
        y = 66
        rect = pygame.Rect(content_x, y, width, 76)
        self.draw_panel(rect, "Algoritmo")
        bw = (width - 20) // 5
        for i, algorithm in enumerate(Algorithm):
            button = Button((rect.x + 8 + i * bw, rect.y + 28, bw - 4, 34), algorithm.value)
            button.active = algorithm == self.current_algorithm
            button.draw(self.screen, self.tiny_font, self.theme)
            self.buttons[f"alg_{algorithm.name}"] = button

        # Herramientas
        y = 150
        rect = pygame.Rect(content_x, y, width, 110)
        self.draw_panel(rect, "Herramientas de edición")
        tools = list(Tool)
        col_w = (width - 20) // 3
        for i, tool in enumerate(tools):
            row, col = divmod(i, 3)
            button = Button((rect.x + 8 + col * col_w, rect.y + 27 + row * 35, col_w - 5, 29), tool.value)
            button.active = tool == self.active_tool
            button.draw(self.screen, self.tiny_font, self.theme)
            self.buttons[f"tool_{tool.name}"] = button

        # Generador
        y = 268
        rect = pygame.Rect(content_x, y, width, 128)
        self.draw_panel(rect, "Generador de mapas")
        dropdown = pygame.Rect(rect.x + 8, rect.y + 28, width - 16, 30)
        pygame.draw.rect(self.screen, self.theme["button"], dropdown, border_radius=7)
        pygame.draw.rect(self.screen, self.theme["border"], dropdown, 1, border_radius=7)
        self.screen.blit(self.small_font.render(self.map_type, True, self.theme["text"]), (dropdown.x + 9, dropdown.y + 7))
        self.screen.blit(self.small_font.render("▼", True, self.theme["muted"]), (dropdown.right - 22, dropdown.y + 7))
        self.buttons["map_dropdown"] = Button(dropdown, "")
        self.density_slider.rect = pygame.Rect(rect.x + 10, rect.y + 85, width - 145, 8)
        self.density_slider.draw(self.screen, self.tiny_font, self.theme)
        generate = Button((rect.right - 125, rect.y + 76, 115, 31), "Generar", icon="⚙")
        generate.draw(self.screen, self.small_font, self.theme)
        self.buttons["generate"] = generate

        # Ejecución opcional
        y = 404
        rect = pygame.Rect(content_x, y, width, 126)
        self.draw_panel(rect, "Resultado y animación")
        labels = [
            ("animation", "Ocultar animación" if self.animation_enabled else "Mostrar animación"),
            ("step", "Siguiente paso"),
            ("play", "Continuar" if self.paused else "Pausar"),
            ("restart", "Reiniciar animación"),
        ]
        bw2 = (width - 24) // 2
        for i, (key, label) in enumerate(labels):
            row, col = divmod(i, 2)
            button = Button((rect.x + 8 + col * (bw2 + 8), rect.y + 27 + row * 36, bw2, 30), label)
            button.active = key == "animation" and self.animation_enabled
            button.draw(self.screen, self.tiny_font, self.theme)
            self.buttons[key] = button
        self.speed_slider.rect = pygame.Rect(rect.x + 10, rect.bottom - 15, width - 20, 7)
        self.speed_slider.draw(self.screen, self.tiny_font, self.theme)

        # Información educativa compacta
        y = 538
        rect = pygame.Rect(content_x, y, width, 70)
        self.draw_panel(rect, "Información educativa")
        info = ALGORITHM_INFO[self.current_algorithm]
        self.screen.blit(self.tiny_font.render(info["description"], True, self.theme["text"]), (rect.x + 10, rect.y + 27))
        details = f"Tiempo: {info['time']}  |  Óptimo: {info['optimal']}"
        self.screen.blit(self.tiny_font.render(details, True, self.theme["muted"]), (rect.x + 10, rect.y + 47))

        # Leyenda dentro de la barra lateral
        y = 616
        rect = pygame.Rect(content_x, y, width, 116)
        self.draw_panel(rect, "Leyenda del mapa")
        legend_items = [
            (self.theme["start"], "I: inicio"),
            (self.theme["goal"], "M: meta"),
            (self.theme["obstacle"], "Obstáculo"),
            (self.theme["path"], "Camino final"),
            (self.theme["visited_end"], "Nodo explorado"),
            (self.theme["frontier"], "Frontera pendiente"),
            (self.theme["current"], "Nodo actual"),
            (self.theme["npc"], "NPC"),
        ]
        col_width = (width - 20) // 2
        for i, (color, label) in enumerate(legend_items):
            row, col = divmod(i, 2)
            lx = rect.x + 10 + col * col_width
            ly = rect.y + 27 + row * 20
            pygame.draw.rect(self.screen, color, (lx, ly + 1, 12, 12), border_radius=3)
            pygame.draw.rect(self.screen, self.theme["border"], (lx, ly + 1, 12, 12), 1, border_radius=3)
            self.screen.blit(self.tiny_font.render(label, True, self.theme["muted"]), (lx + 17, ly))

        # Instrucciones y acciones visibles
        y = 740
        rect = pygame.Rect(content_x, y, width, 72)
        self.draw_panel(rect, "Controles")
        self.screen.blit(self.tiny_font.render("1–5 algoritmo | Espacio reproducir/pausar | → siguiente paso", True, self.theme["muted"]), (rect.x + 10, rect.y + 24))
        self.screen.blit(self.tiny_font.render("TAB comparar | R reiniciar | B comparar | Auto NPC activa/desactiva el movimiento", True, self.theme["muted"]), (rect.x + 10, rect.y + 40))
        actions = [
            ("benchmark", "Comparar"),
            ("move_npc", "Mover NPC"),
            ("auto_npc", "Auto NPC: ON" if self.auto_move_npcs else "Auto NPC: OFF"),
            ("theme", "Cambiar tema"),
        ]
        button_w = (width - 34) // 4
        for i, (key, label) in enumerate(actions):
            button = Button((rect.x + 8 + i * (button_w + 6), rect.bottom - 22, button_w, 20), label)
            button.active = key == "auto_npc" and self.auto_move_npcs
            button.draw(self.screen, self.tiny_font, self.theme)
            self.buttons[key] = button

        if self.message and pygame.time.get_ticks() - self.message_time < 3000:
            msg = pygame.Rect(content_x, h - 35, width, 26)
            pygame.draw.rect(self.screen, self.theme["panel_2"], msg, border_radius=7)
            pygame.draw.rect(self.screen, self.theme["accent"], msg, 1, border_radius=7)
            self.screen.blit(self.tiny_font.render(self.message, True, self.theme["text"]), (msg.x + 8, msg.y + 7))

        self.draw_dropdowns()

    def draw_dropdowns(self):
        if self.map_dropdown_open:
            anchor = self.buttons["map_dropdown"].rect
            item_h = 26
            menu = pygame.Rect(anchor.x, anchor.bottom + 2, anchor.width, item_h * len(self.map_types))
            pygame.draw.rect(self.screen, self.theme["panel"], menu, border_radius=7)
            pygame.draw.rect(self.screen, self.theme["border"], menu, 1, border_radius=7)
            for i, item in enumerate(self.map_types):
                r = pygame.Rect(menu.x, menu.y + i * item_h, menu.width, item_h)
                if r.collidepoint(pygame.mouse.get_pos()):
                    pygame.draw.rect(self.screen, self.theme["button_hover"], r)
                self.screen.blit(self.tiny_font.render(item, True, self.theme["text"]), (r.x + 8, r.y + 7))
            self.map_menu_rect = menu

    def draw_bottom(self):
        x = 0
        y = self.grid_height_px
        width = self.screen.get_width() - self.sidebar_width
        height = self.screen.get_height() - y
        rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, self.theme["bg"], rect)
        pygame.draw.line(self.screen, self.theme["border"], (0, y), (width, y), 1)

        # Tabla estadística
        table = pygame.Rect(10, y + 10, min(520, width * 0.62), height - 20)
        self.draw_panel(table, f"Comparativa confiable — {self.benchmark_repetitions} ejecuciones")
        headers = ["Método", "Prom.", "Mín.", "Máx.", "Desv.", "Nodos", "Pasos"]
        xs = [table.x + 10, table.x + 100, table.x + 160, table.x + 220, table.x + 280, table.x + 350, table.x + 420]
        for text, tx in zip(headers, xs):
            self.screen.blit(self.tiny_font.render(text, True, self.theme["muted"]), (tx, table.y + 27))
        row_y = table.y + 46
        for algorithm in Algorithm:
            data = self.system.algorithm_stats[algorithm]
            if algorithm == self.best_algorithm:
                pygame.draw.rect(self.screen, self.theme["panel_2"], (table.x + 5, row_y - 3, table.width - 10, 22), border_radius=5)
            values = [
                ("★ " if algorithm == self.best_algorithm else "") + algorithm.value,
                f"{data['mean']:.3f}",
                f"{data['min']:.3f}",
                f"{data['max']:.3f}",
                f"{data['std']:.3f}",
                f"{data['visited_mean']:.0f}",
                str(data["steps"]) if data["found"] else "—",
            ]
            for value, tx in zip(values, xs):
                color = self.theme["path"] if algorithm == self.best_algorithm else self.theme["text"]
                self.screen.blit(self.tiny_font.render(value, True, color), (tx, row_y))
            row_y += 25

        # Gráfico de barras
        chart = pygame.Rect(table.right + 10, y + 10, width - table.right - 20, height - 20)
        if chart.width > 160:
            self.draw_panel(chart, "Gráfico comparativo")
            metrics = {
                "Tiempo promedio": lambda d: d["mean"],
                "Nodos explorados": lambda d: d["visited_mean"],
                "Longitud": lambda d: d["steps"],
                "Costo total": lambda d: d["steps"],
            }
            metric_names = list(metrics)
            metric_button = pygame.Rect(chart.x + 10, chart.y + 25, chart.width - 20, 24)
            pygame.draw.rect(self.screen, self.theme["button"], metric_button, border_radius=6)
            self.screen.blit(self.tiny_font.render(self.chart_metric + " ▼", True, self.theme["text"]), (metric_button.x + 7, metric_button.y + 6))
            self.buttons["metric_dropdown"] = Button(metric_button, "")
            getter = metrics[self.chart_metric]
            values = [getter(self.system.algorithm_stats[a]) for a in Algorithm]
            max_value = max(values) if values else 1
            max_value = max(max_value, 0.000001)
            baseline = chart.bottom - 28
            bar_area_h = max(20, chart.height - 88)
            slot = max(18, (chart.width - 24) // len(Algorithm))
            for i, (algorithm, value) in enumerate(zip(Algorithm, values)):
                bh = int(bar_area_h * value / max_value)
                bx = chart.x + 12 + i * slot
                bar = pygame.Rect(bx, baseline - bh, max(8, slot - 8), bh)
                pygame.draw.rect(self.screen, self.theme["accent"], bar, border_radius=4)
                label = self.tiny_font.render(algorithm.value[:4], True, self.theme["muted"])
                self.screen.blit(label, label.get_rect(center=(bar.centerx, baseline + 10)))
                value_label = self.tiny_font.render(f"{value:.2f}", True, self.theme["text"])
                self.screen.blit(value_label, value_label.get_rect(center=(bar.centerx, max(chart.y + 55, bar.y - 8))))

            if self.metric_dropdown_open:
                item_h = 24
                menu = pygame.Rect(metric_button.x, metric_button.bottom + 2, metric_button.width, item_h * len(metric_names))
                pygame.draw.rect(self.screen, self.theme["panel"], menu, border_radius=6)
                pygame.draw.rect(self.screen, self.theme["border"], menu, 1, border_radius=6)
                for i, item in enumerate(metric_names):
                    r = pygame.Rect(menu.x, menu.y + i * item_h, menu.width, item_h)
                    if r.collidepoint(pygame.mouse.get_pos()):
                        pygame.draw.rect(self.screen, self.theme["button_hover"], r)
                    self.screen.blit(self.tiny_font.render(item, True, self.theme["text"]), (r.x + 7, r.y + 6))
                self.metric_menu_rect = menu

    def handle_sidebar_click(self, pos):
        if self.map_dropdown_open and hasattr(self, "map_menu_rect") and self.map_menu_rect.collidepoint(pos):
            index = (pos[1] - self.map_menu_rect.y) // 26
            if 0 <= index < len(self.map_types):
                self.map_type = self.map_types[index]
            self.map_dropdown_open = False
            return True

        if self.metric_dropdown_open and hasattr(self, "metric_menu_rect") and self.metric_menu_rect.collidepoint(pos):
            metrics = ["Tiempo promedio", "Nodos explorados", "Longitud", "Costo total"]
            index = (pos[1] - self.metric_menu_rect.y) // 24
            if 0 <= index < len(metrics):
                self.chart_metric = metrics[index]
            self.metric_dropdown_open = False
            return True

        for algorithm in Algorithm:
            button = self.buttons.get(f"alg_{algorithm.name}")
            if button and button.clicked(pos):
                self.current_algorithm = algorithm
                self.animation_enabled = False
                self.simultaneous_mode = False
                self.show_algorithm_result()
                self.update_all_npc_paths()
                self.show_message(f"Resultado completo: {algorithm.value} · NPC actualizados")
                return True

        for tool in Tool:
            button = self.buttons.get(f"tool_{tool.name}")
            if button and button.clicked(pos):
                self.active_tool = tool
                self.show_message(f"Herramienta: {tool.value}")
                return True

        actions = {
            "generate": self.generate_selected_map,
            "step": self.step_search,
            "benchmark": self.run_benchmark,
            "move_npc": self.move_npcs,
        }
        for key, action in actions.items():
            button = self.buttons.get(key)
            if button and button.clicked(pos):
                action()
                return True

        if self.buttons.get("animation") and self.buttons["animation"].clicked(pos):
            self.toggle_animation()
            return True
        if self.buttons.get("restart") and self.buttons["restart"].clicked(pos):
            if self.animation_enabled:
                self.reset_search()
                self.show_message("Animación reiniciada")
            else:
                self.show_algorithm_result()
                self.show_message("Resultado recalculado")
            return True
        if self.buttons.get("play") and self.buttons["play"].clicked(pos):
            if not self.animation_enabled and not self.simultaneous_mode:
                self.show_message("Activa Mostrar animación para reproducir la búsqueda")
                return True
            self.paused = not self.paused
            self.last_step_time = pygame.time.get_ticks()
            return True
        if self.buttons.get("compare") and self.buttons["compare"].clicked(pos):
            self.simultaneous_mode = not self.simultaneous_mode
            self.animation_enabled = self.simultaneous_mode
            self.reset_search()
            self.show_message("Vista simultánea activa" if self.simultaneous_mode else "Vista individual")
            return True
        if self.buttons.get("auto_npc") and self.buttons["auto_npc"].clicked(pos):
            self.auto_move_npcs = not self.auto_move_npcs
            self.npc_timer = pygame.time.get_ticks()
            self.show_message("Movimiento automático de NPC activado" if self.auto_move_npcs else "Movimiento automático de NPC desactivado")
            return True
        if self.buttons.get("theme") and self.buttons["theme"].clicked(pos):
            self.theme_name = "light" if self.theme_name == "dark" else "dark"
            self.theme = LIGHT if self.theme_name == "light" else DARK
            return True
        if self.buttons.get("map_dropdown") and self.buttons["map_dropdown"].clicked(pos):
            self.map_dropdown_open = not self.map_dropdown_open
            return True
        if self.buttons.get("metric_dropdown") and self.buttons["metric_dropdown"].clicked(pos):
            self.metric_dropdown_open = not self.metric_dropdown_open
            return True
        return False

    def apply_tool(self, cell):
        if cell is None:
            return
        x, y = cell
        if self.active_tool == Tool.START:
            self.set_start(cell)
        elif self.active_tool == Tool.GOAL:
            self.set_goal(cell)
        elif self.active_tool == Tool.OBSTACLE:
            if cell not in (self.system.start, self.system.goal):
                self.system.grid[y][x] = TileType.OBSTACLE
                self.refresh_after_map_change(benchmark=False)
        elif self.active_tool == Tool.ERASE:
            if cell not in (self.system.start, self.system.goal):
                self.system.grid[y][x] = TileType.EMPTY
                self.refresh_after_map_change(benchmark=False)
        elif self.active_tool == Tool.NPC:
            self.add_npc(cell)
        elif self.active_tool == Tool.SELECT:
            self.system.selected_npc = next((n for n in self.system.npcs if (n.x, n.y) == cell), None)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_SPACE:
                    if self.animation_enabled or self.simultaneous_mode:
                        self.paused = not self.paused
                    else:
                        self.show_message("Activa Mostrar animación para reproducir")
                elif event.key == pygame.K_RIGHT:
                    self.step_search()
                elif event.key == pygame.K_r:
                    if self.animation_enabled:
                        self.reset_search()
                    else:
                        self.show_algorithm_result()
                elif event.key == pygame.K_b:
                    self.run_benchmark()
                elif event.key == pygame.K_TAB:
                    self.simultaneous_mode = not self.simultaneous_mode
                    self.animation_enabled = self.simultaneous_mode
                    self.reset_search()
                elif pygame.K_1 <= event.key <= pygame.K_5:
                    self.current_algorithm = list(Algorithm)[event.key - pygame.K_1]
                    self.animation_enabled = False
                    self.simultaneous_mode = False
                    self.show_algorithm_result()
                    self.update_all_npc_paths()
                    self.show_message(f"Resultado completo: {self.current_algorithm.value} · NPC actualizados")
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.speed_slider.handle_event(event) or self.density_slider.handle_event(event):
                    continue
                if event.pos[0] >= self.screen.get_width() - self.sidebar_width:
                    self.handle_sidebar_click(event.pos)
                elif event.pos[1] >= self.grid_height_px:
                    self.handle_sidebar_click(event.pos)
                else:
                    self.drawing = True
                    self.apply_tool(self.cell_at_mouse(event.pos))
            elif event.type == pygame.MOUSEBUTTONUP:
                self.drawing = False
                self.speed_slider.handle_event(event)
                self.density_slider.handle_event(event)
                if self.active_tool in (Tool.OBSTACLE, Tool.ERASE):
                    self.run_benchmark()
            elif event.type == pygame.MOUSEMOTION:
                self.speed_slider.handle_event(event)
                self.density_slider.handle_event(event)
                self.hover_cell = self.cell_at_mouse(event.pos)
                if self.drawing and self.active_tool in (Tool.OBSTACLE, Tool.ERASE):
                    self.apply_tool(self.hover_cell)

    def update(self):
        self.update_search_animation()

        now = pygame.time.get_ticks()

        # Ejecuta el benchmark una sola vez, después de que la interfaz
        # ya haya tenido tiempo de dibujarse en el navegador.
        if self.pending_initial_benchmark:
            if now - self.initial_benchmark_time >= 1000:
                self.pending_initial_benchmark = False
                self.run_benchmark()

        if self.auto_move_npcs and self.system.npcs:
            if now - self.npc_timer > 180:
                self.move_npcs()
                self.npc_timer = now

    def draw(self):
        self.screen.fill(self.theme["bg"])
        if self.simultaneous_mode:
            self.draw_simultaneous()
        else:
            self.draw_single_grid()
        self.draw_bottom()
        self.draw_sidebar()
        pygame.display.flip()

    async def run(self):
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(60)

            # Cede el control al navegador. Es obligatorio para Pygbag/WebAssembly.
            await asyncio.sleep(0)

        pygame.quit()


async def main():
    try:
        game = Game()
        await game.run()
    except Exception as error:
        pygame.quit()
        print(f"Error inesperado: {error}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
